import { assessUrl } from './detector.js'

const elements = {
  status: document.querySelector('#status'),
  icon: document.querySelector('#status-icon'),
  kicker: document.querySelector('#kicker'),
  heading: document.querySelector('#heading'),
  description: document.querySelector('#description'),
  domain: document.querySelector('#domain'),
  score: document.querySelector('#score'),
  signals: document.querySelector('#signals'),
  message: document.querySelector('#message'),
  actions: document.querySelector('#actions'),
}

const createButton = (label, className, onClick) => {
  const button = document.createElement('button')
  button.type = 'button'
  button.className = className
  button.textContent = label
  button.addEventListener('click', onClick)
  return button
}

function render(assessment, tabId, blockedUrl, targetUrl) {
  elements.status.className = `status ${assessment.risk}`
  elements.icon.textContent = assessment.risk === 'safe' ? '✓' : assessment.risk === 'suspicious' ? '!' : '×'
  elements.kicker.textContent = blockedUrl ? 'THREAT INTERCEPTED' : assessment.source === 'server' ? 'SHIELD AI ANALYSIS' : 'LOCAL CHECK · SERVER OFFLINE'
  elements.heading.textContent = assessment.risk === 'safe' ? "You're safe" : assessment.risk === 'suspicious' ? 'Something looks off' : assessment.risk === 'danger' ? 'Site blocked' : 'Page unavailable'
  elements.description.textContent = assessment.summary || (assessment.risk === 'safe'
    ? 'No obvious warning signs found in this local demo check.'
    : assessment.risk === 'suspicious'
      ? 'Shield recommends checking before you continue.'
      : assessment.risk === 'danger'
        ? 'This page matches the prototype’s dangerous-site rules.'
        : 'Shield cannot inspect browser-internal pages.')
  elements.domain.textContent = assessment.host
  elements.score.textContent = String(assessment.score).padStart(2, '0')
  elements.message.textContent = assessment.source === 'server'
    ? 'Checked when you opened Shield. The submitted URL is sent to Shield and threat-intelligence providers.'
    : assessment.risk === 'safe'
    ? 'Shield is watching quietly in the background.'
    : assessment.risk === 'suspicious'
      ? 'Avoid entering personal details until you verify this site independently.'
      : assessment.risk === 'danger'
        ? 'This navigation was stopped before the page could load.'
        : 'Open a regular website to check its address.'

  elements.signals.replaceChildren()
  assessment.signals.forEach((signal) => {
    const item = document.createElement('div')
    item.className = 'signal'
    const mark = document.createElement('span')
    mark.textContent = assessment.risk === 'safe' ? '✓' : '!'
    const text = document.createElement('span')
    text.textContent = signal
    item.append(mark, text)
    elements.signals.append(item)
  })

  elements.actions.replaceChildren()
  if (assessment.authRequired) {
    elements.actions.append(createButton('Sign in to Shield', 'button primary-button', () => chrome.runtime.openOptionsPage()))
  } else if (assessment.risk === 'danger') {
    elements.actions.append(
      createButton('Leave site', 'button danger-button', () => chrome.tabs.update(tabId, { url: 'chrome://newtab/' })),
      createButton('See why', 'button quiet-button', () => openEvidence(targetUrl, assessment)),
    )
  } else if (assessment.risk === 'suspicious') {
    elements.actions.append(
      createButton('Review signals', 'button primary-button', () => openEvidence(targetUrl, assessment)),
      createButton('Dismiss', 'button quiet-button', () => window.close()),
    )
  } else {
    elements.actions.append(createButton('Check again', 'button primary-button', () => inspect(tabId)))
  }
}

function openEvidence(url, assessment) {
  const query = new URLSearchParams({
    url,
    assessment: JSON.stringify(assessment),
  })
  chrome.tabs.create({ url: chrome.runtime.getURL(`evidence.html?${query}`) })
}

async function getApiBase() {
  const stored = await chrome.storage.sync.get('shieldApiBaseUrl')
  return typeof stored.shieldApiBaseUrl === 'string' && stored.shieldApiBaseUrl
    ? stored.shieldApiBaseUrl.replace(/\/+$/, '')
    : 'http://localhost:3000'
}

async function authorizedCheck(apiBase, accessToken, targetUrl, pageSignals) {
  return fetch(`${apiBase}/api/extension/check`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`,
    },
    body: JSON.stringify({ url: targetUrl, signals: pageSignals }),
  })
}

async function inspect(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId)
    const currentUrl = new URL(tab.url)
    const blockedUrl = currentUrl.searchParams.get('url')
    const targetUrl = blockedUrl ?? tab.url
    const targetHost = new URL(targetUrl).hostname
    let pageSignals = {}

    if (!blockedUrl && ['http:', 'https:'].includes(currentUrl.protocol)) {
      try {
        pageSignals = await chrome.runtime.sendMessage({ type: 'shield:get-page-signals', tabId })
      } catch {
        try {
          pageSignals = await chrome.tabs.sendMessage(tabId, { type: 'shield:inspect' })
        } catch {
          pageSignals = {}
        }
      }
    }

    let assessment
    try {
      const apiBase = await getApiBase()
      const stored = await chrome.storage.local.get(['shieldAccessToken', 'shieldRefreshToken'])
      if (typeof stored.shieldAccessToken !== 'string') {
        render({
          risk: 'unknown',
          score: 0,
          host: targetHost,
          signals: [blockedUrl ? 'This URL was locally blocked. Connect your account for trained model analysis.' : 'Connect your Shield account to save and analyze this page.'],
          source: 'local',
          authRequired: true,
        }, tabId, null, targetUrl)
        return
      }

      let response = await authorizedCheck(apiBase, stored.shieldAccessToken, targetUrl, pageSignals ?? {})
      if (response.status === 401 && typeof stored.shieldRefreshToken === 'string') {
        const refreshed = await fetch(`${apiBase}/api/extension/refresh`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ refresh_token: stored.shieldRefreshToken }),
        })
        const session = await refreshed.json().catch(() => ({}))
        if (!refreshed.ok || typeof session.access_token !== 'string') {
          await chrome.storage.local.remove(['shieldAccessToken', 'shieldRefreshToken'])
          render({
            risk: 'unknown',
            score: 0,
            host: targetHost,
            signals: ['Your Shield session expired. Sign in again to continue.'],
            source: 'local',
            authRequired: true,
          }, tabId, null, targetUrl)
          return
        }
        await chrome.storage.local.set({
          shieldAccessToken: session.access_token,
          shieldRefreshToken: session.refresh_token,
        })
        response = await authorizedCheck(apiBase, session.access_token, targetUrl, pageSignals ?? {})
      }
      if (!response.ok) throw new Error(`Shield API returned ${response.status}.`)
      const result = await response.json()
      const modelResult = result.dataset_classification?.type === 'url'
        ? `Trained phishing detector: ${result.dataset_classification.label === 'malicious' ? 'malicious' : 'likely benign'} (${Math.round(result.dataset_classification.confidence * 100)}% confidence)`
        : null
      const localAssessment = blockedUrl ? assessUrl(targetUrl) : null
      const riskOrder = { safe: 0, suspicious: 1, danger: 2 }
      const keepLocalBlock = localAssessment && riskOrder[localAssessment.risk] > riskOrder[result.risk_level]
      assessment = {
        risk: keepLocalBlock ? localAssessment.risk : result.risk_level,
        score: Math.max(result.risk_score, localAssessment?.score ?? 0),
        host: targetHost,
        signals: [
          ...(result.flags ?? []).map((flag) => flag.type),
          ...(modelResult ? [modelResult] : []),
          ...(keepLocalBlock ? localAssessment.signals : []),
        ],
        summary: keepLocalBlock
          ? 'The extension retained its local block warning and also analyzed the original URL with the backend.'
          : result.summary,
        source: 'server',
        createdAt: result.created_at,
        datasetClassification: result.dataset_classification ?? null,
      }
    } catch (error) {
      assessment = {
        ...assessUrl(targetUrl, pageSignals ?? {}),
        source: 'local',
        host: targetHost,
        summary: error instanceof Error ? `Shield API unavailable: ${error.message}` : 'Could not reach the Shield API.',
      }
    }
    render(assessment, tabId, blockedUrl, targetUrl)
  } catch {
    render({ risk: 'unknown', score: 0, host: 'Unavailable', signals: ['Could not read the active tab'], source: 'local' }, tabId)
  }
}

chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(([tab]) => {
  if (typeof tab?.id !== 'number') {
    render({ risk: 'unknown', score: 0, host: 'Unavailable', signals: ['No active browser tab'], source: 'local' }, -1)
    return
  }
  void inspect(tab.id)
})
